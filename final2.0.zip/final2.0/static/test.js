
// This is an array of objects that stores the personality trait that is prompted to the user and the weight for each prompt. 
// If a personality trait is considered more introverted, it will have a negative weight.
// If a personlity trait is considered more extroverted, it will have a positive weight.
var counters = {
    D: 0,
    I: 0,
    C: 0,
    S: 0
};
// Update the prompts array to only include the provided five prompts
var prompts = [
    {
        prompt: '一個做事認真且值得信賴的人',
        weight: 1,
        class: 'group0',
        counter: {
            D: 0,
            I: function (x) { return -x; },
            C: 0,
            S: function (x) { return 10 * x; }
        }
    },
    {
        prompt: '個性溫和富有同情心的人',
        weight: 1,
        class: 'group1',
        counter: {
            D: function (x) { return -x; },
            I: 0,
            C: function (x) { return 10 * x; },
            S: 0
        }
    },
    {
        prompt: '有活力且受人愛戴的人',
        weight: 1,
        class: 'group2',
        counter: {
            D: 0,
            I: function (x) { return 10 * x; },
            C: 0,
            S: function (x) { return -x; }
        }
    },
    {
        prompt: '懂得察言觀色、善解人意，懂得閱讀空氣的人',
        weight: 1,
        class: 'group3',
        counter: {
            D: function (x) { return -x; },
            I: 0,
            C: 0,
            S: 0
        }
    },
    {
        prompt: '獨立、勤勞的人',
        weight: 1,
        class: 'group4',
        counter: {
            D: function (x) { return 10 * x; },
            I: function (x) { return -x; },
            C: 0,
            S: 0
        }
    }
];

// Function to update counters on submit
function updateCounters(value) {
    switch (value) {
        case 1: counters.D++; break;
        case 2: counters.I++; break;
        case 3: counters.C++; break;
        case 4: counters.S++; break;
        case 5: counters.D--; counters.I--; counters.C--; counters.S--; break;
    }
}

function displayCounters() {
    $('#D-counter').text('D: ' + counters.D);
    $('#I-counter').text('I: ' + counters.I);
    $('#C-counter').text('C: ' + counters.C);
    $('#S-counter').text('S: ' + counters.S);
}
// 使用 jQuery 的 on 方法來綁定點擊事件處理器
// 這樣可以確保動態添加的按鈕也能綁定事件
$(document).on('click', '.value-btn', function () {
    var classList = $(this).attr('class');
    var classArr = classList.split(" ");
    var this_group = classArr.find(function (c) {
        return c.startsWith('group');
    });
    var value = parseInt($(this).text(), 10); // Get the button value as integer

    // Update the counters when a button is clicked
    updateCounters(this_group, value);

    // Update the display of counters
    displayCounters();

    // Log the updated counters
    console.log(counters);
});


// This array stores all of the possible values and the weight associated with the value. 
// The stronger agreeance/disagreeance, the higher the weight on the user's answer to the prompt.
var prompt_values = [
    {
        value: '1',
        class: 'btn-default btn-strongly-disagree'
    },
    {
        value: '2',
        class: 'btn-default btn-disagree'
    },
    {
        value: '3',
        class: 'btn-default'
    },
    {
        value: '4',
        class: 'btn-default btn-agree'

    },
    {
        value: '5',
        class: 'btn-default btn-strongly-agree'

    }
]

function createPromptItems() {

    for (var i = 0; i < prompts.length; i++) {
        var prompt_li = document.createElement('li');
        var prompt_p = document.createElement('p');
        var prompt_text = document.createTextNode(prompts[i].prompt);

        prompt_li.setAttribute('class', 'list-group-item prompt');
        prompt_p.appendChild(prompt_text);
        prompt_li.appendChild(prompt_p);

        document.getElementById('quiz').appendChild(prompt_li);
    }
}

function createValueButtons() {
    for (var li_index = 0; li_index < prompts.length; li_index++) {
        var group = document.createElement('div');
        group.className = 'btn-group btn-group-justified';

        for (var i = 0; i < prompt_values.length; i++) {
            var btn_group = document.createElement('div');
            btn_group.className = 'btn-group';

            var button = document.createElement('button');
            var button_text = document.createTextNode(prompt_values[i].value);
            button.className = 'group' + li_index + ' value-btn btn ' + prompt_values[i].class;
            button.appendChild(button_text);

            btn_group.appendChild(button);
            group.appendChild(btn_group);

            document.getElementsByClassName('prompt')[li_index].appendChild(group);
        }
    }
}

createPromptItems();
createValueButtons();

// Keep a running total of the values they have selected. If the total is negative, the user is introverted. If positive, user is extroverted.
// Calculation will sum all of the answers to the prompts using weight of the value * the weight of the prompt.
var total = 0;

// Get the weight associated to group number
function findPromptWeight(prompts, group) {
    var weight = 0;

    for (var i = 0; i < prompts.length; i++) {
        if (prompts[i].class === group) {
            weight = prompts[i].weight;
        }
    }

    return weight;
}

// Get the weight associated to the value
function findValueWeight(values, value) {
    var weight = 0;

    for (var i = 0; i < values.length; i++) {
        if (values[i].value === value) {
            weight = values[i].weight;
        }
    }

    return weight;
}

// When user clicks a value to agree/disagree with the prompt, display to the user what they selected
$('.value-btn').mousedown(function () {
    var classList = $(this).attr('class');
    // console.log(classList);
    var classArr = classList.split(" ");
    // console.log(classArr);
    var this_group = classArr[0];
    // console.log(this_group);

    // If button is already selected, de-select it when clicked and subtract any previously added values to the total
    // Otherwise, de-select any selected buttons in group and select the one just clicked
    // And subtract deselected weighted value and add the newly selected weighted value to the total
    if ($(this).hasClass('active')) {
        $(this).removeClass('active');
        total -= (findPromptWeight(prompts, this_group) * findValueWeight(prompt_values, $(this).text()));
    } else {
        // $('[class='thisgroup).prop('checked', false);
        total -= (findPromptWeight(prompts, this_group) * findValueWeight(prompt_values, $('.' + this_group + '.active').text()));
        // console.log($('.'+this_group+'.active').text());
        $('.' + this_group).removeClass('active');

        // console.log('group' + findValueWeight(prompt_values, $('.'+this_group).text()));
        // $(this).prop('checked', true);
        $(this).addClass('active');
        total += (findPromptWeight(prompts, this_group) * findValueWeight(prompt_values, $(this).text()));
    }

    console.log(total);
})


$('#submit-btn').click(function () {
    // 先重置计数器
    counters = { D: 0, I: 0, C: 0, S: 0 };

    // 遍历每个已激活的按钮并更新计数器
    $('.value-btn.active').each(function () {
        var value = parseInt($(this).text(), 10); // 获取按钮的值
        // 根据值更新计数器
        switch (value) {
            case 1:
                counters.D++;
                break;
            case 2:
                counters.I++;
                break;
            case 3:
                counters.C++;
                break;
            case 4:
                counters.S++;
                break;
            case 5:
                counters.D--;
                counters.I--;
                counters.C--;
                counters.S--;
                break;
        }
    });

    // 更新结果显示
    displayCounters();

    // 显示结果并隐藏测验部分
    $('.results').removeClass('hide').addClass('show');
    $('#quiz').addClass('hide');
    $('#ans').removeClass('hide');
    $('#submit-btn').addClass('hide');
    $('#retake-btn').removeClass('hide');
});

$('#retake-btn').click(function () {
    // 重置计数器
    counters = { D: 0, I: 0, C: 0, S: 0 };

    // 清空结果显示并重置界面
    displayCounters();
    $('#ans').addClass('hide');
    $('#quiz').removeClass('hide');
    $('#submit-btn').removeClass('hide');
    $('#retake-btn').addClass('hide');
    $('.results').addClass('hide');
    $('.results').removeClass('show');
    $('.value-btn').removeClass('active'); // 移除所有选项的激活状态
});